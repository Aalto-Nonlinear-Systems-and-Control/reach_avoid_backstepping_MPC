

# ####################################### POLYNOMIAL TEST 1 #####################################

# import sympy as sp

# # Define the symbols.
# y = sp.symbols("y:2")

# # New polynomial for k1_0 (extracted from your 95.5% SOP certificate for y1)
# k1_0 = (
#       0.12921 * y[0]**2 
#     - 1.9906 * y[0] * y[1] 
#     - 2.2629 * y[0] 
#     - 0.40462 * y[1]**2 
#     - 0.010898 * y[1] 
#     - 0.0036253
# )

# # New polynomial for k1_1 (extracted from your 95.5% SOP certificate for y2)
# k1_1 = (
#       1.1906 * y[0]**2 
#     + 0.2547 * y[0] * y[1] 
#     + 0.40567 * y[0] 
#     + 0.55822 * y[1]**2 
#     - 2.7322 * y[1] 
#     + 0.0000092038
# )

# # Delta directly from your MOSEK output log
# val_delta = -3.3413100565e-11

# # IMPORTANT: I do not have the printed lambda from your specific MATLAB workspace.
# # Please replace this placeholder with the exact `k1_lambda` or `k1_lambda_opt` 
# # from your MATLAB run before executing!
# val_lambda = 0.0053



# ####################################### POLYNOMIAL TEST 2 #####################################

# import sympy as sp

# # Define the symbols.
# y = sp.symbols("y:2")

# # New polynomial for k1_0 (extracted from your latest SOP certificate for y1)
# k1_0 = (
#       18.3805 * y[0]**2 
#     - 141.1464 * y[0] * y[1] 
#     - 55.0692 * y[0] 
#     - 62.5541 * y[1]**2 
#     - 77.4458 * y[1] 
#     - 0.012314
# )

# # New polynomial for k1_1 (extracted from your latest SOP certificate for y2)
# k1_1 = (
#       146.867 * y[0]**2 
#     + 100.9626 * y[0] * y[1] 
#     + 68.6362 * y[0] 
#     + 18.1677 * y[1]**2 
#     - 48.4896 * y[1] 
#     + 0.38751
# )

# # Delta directly from your MOSEK output log
# val_delta = 1.6006e-09

# # Lambda fixed from your vanilla solver run
# val_lambda = 0.0065





####################################### POLYNOMIAL TEST 3 #####################################
import sympy as sp

# Define the symbols.
y = sp.symbols("y:2")

# New polynomial for k1_0 (extracted from your 200-sample SOP for y1)
k1_0 = (
      - 2.5736 * y[0]**2 
      - 17.536 * y[0] * y[1] 
      - 9.7966 * y[0] 
      + 8.5476 * y[1]**2 
      - 6.2783 * y[1] 
      + 0.038625
)

# New polynomial for k1_1 (extracted from your 200-sample SOP for y2)
k1_1 = (
      19.8109 * y[0]**2 
      - 5.8277 * y[0] * y[1] 
      + 5.8529 * y[0] 
      + 4.7392 * y[1]**2 
      - 11.7492 * y[1] 
      - 0.050565
)

# Delta directly from your MOSEK output log
val_delta = 4.1233e-10

# Lambda fixed from your vanilla solver run
val_lambda = 0.0065



####################################### DUBINS TEST #############################################








